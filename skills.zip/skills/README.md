# MCP Atlassian Skills

This directory contains Skills for the community `mcp-atlassian` MCP Server. These Skills are adapted from the official Atlassian MCP Server Skills, modified to work with the community version's tool set.

## Available Skills

| Skill | Description |
|-------|-------------|
| [capture-tasks-from-meeting-notes](./capture-tasks-from-meeting-notes/) | Extract action items from meeting notes and create Jira issues |
| [generate-status-report](./generate-status-report/) | Generate project status reports and publish to Confluence |
| [search-company-knowledge](./search-company-knowledge/) | Search across Jira and Confluence for company knowledge |
| [spec-to-backlog](./spec-to-backlog/) | Convert Confluence specifications into Jira backlogs |
| [triage-issue](./triage-issue/) | Triage bug reports, find duplicates, and create issues |

## How to Use

### Option 1: With OpenSkills CLI

```bash
# Install OpenSkills if not already installed
npm install -g openskills

# Install these skills
openskills install ./skills

# Sync to AGENTS.md
openskills sync
```

### Option 2: Manual Installation

1. Copy the desired skill folder to your `.claude/skills/` directory
2. The skill will be automatically available in Claude Code

### Option 3: Direct Reference

You can also reference these skills directly in your prompts:
```
Load the search-company-knowledge skill and help me find information about our authentication system.
```

## Tool Compatibility

These Skills have been adapted to use `mcp-atlassian` community version tools.

See [TOOL_MAPPING.md](./TOOL_MAPPING.md) for:
- Complete tool name mappings (official → community)
- Parameter differences
- Missing tools that need future development

## Prerequisites

- `mcp-atlassian` MCP Server running (via Docker or local installation)
- Configured Jira and/or Confluence credentials
- Claude Code or compatible AI assistant

## Contributing

When adding new skills or modifying existing ones:

1. Follow the SKILL.md format (YAML frontmatter + Markdown body)
2. Use `mcp-atlassian` tool names (e.g., `jira_search`, not `searchJiraIssuesUsingJql`)
3. Update TOOL_MAPPING.md if you discover new tool gaps
4. Test with actual Jira/Confluence instances

## Credits

- Original Skills by [Atlassian](https://github.com/atlassian/atlassian-mcp-server)
- Adapted for [mcp-atlassian](https://github.com/sooperset/mcp-atlassian) community version
