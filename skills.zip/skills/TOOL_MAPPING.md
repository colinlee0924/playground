# Tool Mapping: Official Atlassian → mcp-atlassian Community

This document maps tools from the official Atlassian MCP Server to the community `mcp-atlassian` version, and tracks missing features that need future development.

---

## ✅ Direct Mappings

These tools can be directly mapped with minor parameter adjustments.

### Jira Tools

| Official Tool | Community Tool | Parameter Changes |
|--------------|----------------|-------------------|
| `searchJiraIssuesUsingJql(cloudId, jql, fields, maxResults)` | `jira_search(jql, fields, limit)` | Remove `cloudId`, rename `maxResults` → `limit` |
| `getJiraIssue(cloudId, issueIdOrKey)` | `jira_get_issue(issue_key, fields)` | Remove `cloudId` |
| `createJiraIssue(cloudId, projectKey, issueTypeName, summary, description, parent)` | `jira_create_issue(project_key, summary, issue_type, description, additional_fields)` | Remove `cloudId`, `parent` goes into `additional_fields={'parent': 'KEY-123'}` |
| `addCommentToJiraIssue(cloudId, issueIdOrKey, commentBody)` | `jira_add_comment(issue_key, comment)` | Remove `cloudId`, rename `commentBody` → `comment` |
| `getVisibleJiraProjects(cloudId, action)` | `jira_get_all_projects()` | Remove parameters |

### Confluence Tools

| Official Tool | Community Tool | Parameter Changes |
|--------------|----------------|-------------------|
| `getConfluencePage(cloudId, pageId, contentFormat)` | `confluence_get_page(page_id, convert_to_markdown)` | Remove `cloudId`, `contentFormat="markdown"` → `convert_to_markdown=True` |
| `createConfluencePage(cloudId, spaceId, title, body, parentId)` | `confluence_create_page(space_key, title, body, parent_id)` | Remove `cloudId`, rename `spaceId` → `space_key` |
| `updateConfluencePage(cloudId, pageId, title, body, version)` | `confluence_update_page(page_id, title, body)` | Remove `cloudId`, version is auto-handled |
| `searchConfluenceUsingCql(cloudId, cql)` | `confluence_search(query, limit)` | Remove `cloudId`, supports both CQL and plain text |

---

## ⚠️ Partial Mappings (Workarounds Available)

These tools have workarounds but may not have full feature parity.

| Official Tool | Community Alternative | Notes |
|--------------|----------------------|-------|
| `lookupJiraAccountId(cloudId, query)` | `jira_get_user_profile(user_identifier)` | Community version takes email, username, or account ID directly |
| `getJiraTransitions(cloudId, issueIdOrKey)` | `jira_get_transitions(issue_key)` | Equivalent functionality |

---

## ❌ Missing Tools (Need Development)

These tools are **not available** in the community version and need to be developed.

### High Priority

| Tool | Description | Use Cases | Suggested Implementation |
|------|-------------|-----------|-------------------------|
| `search(cloudId, query)` | Rovo cross-system search (searches Jira + Confluence simultaneously) | `search-company-knowledge` skill relies heavily on this | Create wrapper that calls both `jira_search` and `confluence_search` in parallel and merges results |

### Medium Priority

| Tool | Description | Use Cases | Suggested Implementation |
|------|-------------|-----------|-------------------------|
| `getConfluenceSpaces(cloudId)` | List all Confluence spaces | Helpful for space discovery | Add to `mcp-atlassian` confluence module |
| `getJiraProjectIssueTypesMetadata(cloudId, projectIdOrKey)` | Get available issue types for a project | Required by `spec-to-backlog`, `triage-issue` | Add to `mcp-atlassian` jira module |

### Low Priority

| Tool | Description | Use Cases | Suggested Implementation |
|------|-------------|-----------|-------------------------|
| `getAccessibleAtlassianResources()` | Get available Atlassian resources | OAuth flow discovery | Not critical for most use cases |
| `getJiraIssueTypeMetaWithFields(cloudId, projectIdOrKey, issueTypeId)` | Get required fields for an issue type | Custom field validation | Add to `mcp-atlassian` jira module |

---

## 🔧 Skill-Specific Adaptations

### capture-tasks-from-meeting-notes
- ✅ Works with current tools
- Uses: `jira_search`, `jira_create_issue`, `jira_get_user_profile`

### generate-status-report
- ✅ Works with current tools
- Uses: `jira_search`, `jira_get_issue`, `confluence_create_page`, `confluence_update_page`

### search-company-knowledge
- ⚠️ **Partial support**: Missing Rovo `search` tool
- **Workaround**: Sequential calls to `confluence_search` + `jira_search`
- Uses: `confluence_search`, `jira_search`, `confluence_get_page`, `jira_get_issue`

### spec-to-backlog
- ⚠️ **Partial support**: Missing `getJiraProjectIssueTypesMetadata`
- **Workaround**: Ask user for issue type instead of auto-detecting
- Uses: `confluence_get_page`, `confluence_search`, `jira_get_all_projects`, `jira_create_issue`

### triage-issue
- ⚠️ **Partial support**: Missing `getJiraProjectIssueTypesMetadata`
- **Workaround**: Default to "Bug" issue type, let user override
- Uses: `jira_search`, `jira_get_issue`, `jira_add_comment`, `jira_create_issue`

---

## 📋 Development Backlog

### To be implemented in mcp-atlassian:

1. **`jira_get_project_issue_types(project_key)`**
   - Returns: List of available issue types (Epic, Story, Task, Bug, etc.)
   - Priority: Medium
   - Effort: Low

2. **`jira_get_issue_type_fields(project_key, issue_type)`**
   - Returns: Required and optional fields for an issue type
   - Priority: Low
   - Effort: Medium

3. **`confluence_get_spaces(limit)`**
   - Returns: List of Confluence spaces
   - Priority: Medium
   - Effort: Low

4. **`unified_search(query, sources)` (Rovo equivalent)**
   - Searches both Jira and Confluence in parallel
   - Returns: Merged, ranked results
   - Priority: High
   - Effort: Medium

---

## 📝 Contributing

If you implement any of the missing tools:

1. Add the tool to the appropriate module in `src/mcp_atlassian/`
2. Update the tool registration in `src/mcp_atlassian/servers/`
3. Add tests in `tests/`
4. Update this document to mark the tool as ✅ available
5. Submit a PR to the mcp-atlassian repository
