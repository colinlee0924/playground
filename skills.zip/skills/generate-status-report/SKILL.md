---
name: generate-status-report
description: "Generate project status reports from Jira issues and publish to Confluence. When Claude needs to: (1) Create a status report for a project, (2) Summarize project progress or updates, (3) Generate weekly/daily reports from Jira, (4) Publish status summaries to Confluence, or (5) Analyze project blockers and completion. Queries Jira issues, categorizes by status/priority, and creates formatted reports for delivery managers and executives."
version: community-1.0
adapted_for: mcp-atlassian (community version)
---

# Generate Status Report

## Keywords

status report, project status, weekly update, daily standup, Jira report, project summary, blockers, progress update, Confluence report, sprint report, project update, publish to Confluence, write to Confluence, post report

Automatically query Jira for project status, analyze issues, and generate formatted status reports published to Confluence.

**CRITICAL**: This skill should be **interactive**. Always clarify scope (time period, audience, Confluence destination) with the user before or after generating the report. Do not silently skip Confluence publishing—always offer it.

---

## Tool Reference (Community mcp-atlassian)

This skill uses the following community mcp-atlassian tools:

| Action | Tool | Parameters |
|--------|------|------------|
| Search Jira issues | `jira_search` | `jql`, `fields` (optional), `limit` (optional, default 50) |
| List all projects | `jira_get_all_projects` | (no parameters) |
| Get Confluence page | `confluence_get_page` | `page_id`, `convert_to_markdown` (optional) |
| Create Confluence page | `confluence_create_page` | `space_key`, `title`, `body`, `parent_id` (optional) |
| Update Confluence page | `confluence_update_page` | `page_id`, `title`, `body` |
| Search Confluence | `confluence_search` | `query`, `limit` (optional) |

**Note:** The community version doesn't have `getConfluenceSpaces`. Use `confluence_search` to find existing pages or ask the user for the space key directly.

---

## Workflow

Generating a status report follows these steps:

1. **Identify scope** - Determine project, time period, and target audience
2. **Query Jira** - Fetch relevant issues using JQL queries
3. **Analyze data** - Categorize issues and identify key insights
4. **Format report** - Structure content based on audience and purpose
5. **Publish to Confluence** - Create or update a page with the report

## Step 1: Identify Scope

**IMPORTANT**: If the user's request is missing key information, ASK before proceeding with queries. Do not assume defaults without confirmation for Confluence publishing.

Clarify these details:

**Project identification:**
- Which Jira project key? (e.g., "PROJ", "ENG", "MKTG")
- If the user mentions a project by name but not key, use `jira_get_all_projects` to find the project key

**Time period:**
- If not specified, ask: "What time period should this report cover? (default: last 7 days)"
- Options: Weekly (7 days), Daily (24 hours), Sprint-based (2 weeks), Custom period

**Target audience:**
- If not specified, ask: "Who is this report for? (Executives/Delivery Managers, Team-level, or Daily standup)"
- **Executives/Delivery Managers**: High-level summary with key metrics and blockers
- **Team-level**: Detailed breakdown with issue-by-issue status
- **Daily standup**: Brief update on yesterday/today/blockers

**Report destination:**
- **ALWAYS ASK** if not specified: "Would you like me to publish this report to Confluence? If so, which space key should I use? (e.g., TEAM, ENG, DOCS)"
- If user says yes: Ask for space key
- Determine: New page or update existing page?
- Ask about parent page if creating under a specific section

## Step 2: Query Jira

Use the `jira_search` tool to fetch issues. Build JQL queries based on report needs.

### Common Query Patterns

**All open issues in project:**
```
jira_search(
  jql="project = PROJECT_KEY AND status != Done ORDER BY priority DESC, updated DESC",
  limit=100
)
```

**Issues updated in last week:**
```
jira_search(
  jql="project = PROJECT_KEY AND updated >= -7d ORDER BY priority DESC",
  limit=100
)
```

**High priority and blocked issues:**
```
jira_search(
  jql="project = PROJECT_KEY AND (priority IN (Highest, High) OR status = Blocked) AND status != Done ORDER BY priority DESC",
  limit=50
)
```

**Completed in reporting period:**
```
jira_search(
  jql="project = PROJECT_KEY AND status = Done AND resolved >= -7d ORDER BY resolved DESC",
  limit=50
)
```

### Query Strategy

For most reports, execute multiple targeted queries rather than one large query:

1. **Completed issues**: Get recently resolved tickets
2. **In-progress issues**: Get active work items
3. **Blocked issues**: Get blockers requiring attention
4. **High priority open**: Get critical upcoming work

Use `limit=100` for initial queries.

### Data to Extract

For each issue, capture:
- `key` (e.g., "PROJ-123")
- `summary` (issue title)
- `status` (current state)
- `priority` (importance level)
- `assignee` (who's working on it)
- `created` / `updated` / `resolved` dates
- `description` (if needed for context on blockers)

## Step 3: Analyze Data

Process the retrieved issues to identify:

**Metrics:**
- Total issues by status (Done, In Progress, Blocked, etc.)
- Completion rate (if historical data available)
- Number of high priority items
- Unassigned issue count

**Key insights:**
- Major accomplishments (recently completed high-value items)
- Critical blockers (blocked high priority issues)
- At-risk items (overdue or stuck in progress)
- Resource bottlenecks (one assignee with many issues)

**Categorization:**
Group issues logically:
- By status (Done, In Progress, Blocked)
- By priority (Highest → Low)
- By assignee or team
- By component or epic (if relevant)

## Step 4: Format Report

Select the appropriate template based on audience.

### For Executives and Delivery Managers

Use **Executive Summary Format**:
- Brief overall status (On Track / At Risk / Blocked)
- Key metrics (total, completed, in progress, blocked)
- Top 3 highlights (major accomplishments)
- Critical blockers with impact
- Upcoming priorities

**Keep it concise** - 1-2 pages maximum. Focus on what matters to decision-makers.

### For Team-Level Reports

Use **Detailed Technical Format**:
- Completed issues listed with keys
- In-progress issues with assignee and priority
- Blocked issues with blocker description and action needed
- Risks and dependencies
- Next period priorities

**Include more detail** - Team needs issue-level visibility.

### For Daily Updates

Use **Daily Standup Format**:
- What was completed yesterday
- What's planned for today
- Current blockers
- Brief notes

**Keep it brief** - This is a quick sync, not comprehensive analysis.

## Step 5: Publish to Confluence

**After generating the report, ALWAYS offer to publish to Confluence** (unless user explicitly said not to).

If user hasn't specified Confluence details yet, ask:
- "Would you like me to publish this report to Confluence?"
- "Which Confluence space key should I use? (e.g., TEAM, ENG, DOCS)"
- "Should this be nested under a specific parent page? (provide page ID if so)"

Use the `confluence_create_page` tool to publish the report.

**Page creation:**
```
confluence_create_page(
  space_key="TEAM",
  title="[Project Name] - Status Report - [Date]",
  body="[formatted report in Markdown or HTML]",
  parent_id="[optional - parent page ID if nesting under another page]"
)
```

**Title format examples:**
- "Project Phoenix - Weekly Status - Dec 3, 2025"
- "Engineering Sprint 23 - Status Report"
- "Q4 Initiatives - Status Update - Week 49"

**Body formatting:**
Write the report content in Markdown. The tool will handle conversion. Use:
- Headers (`#`, `##`, `###`) for structure
- Bullet points for lists
- Bold (`**text**`) for emphasis
- Tables for metrics if needed
- Links to Jira issues: `[PROJ-123](https://yourinstance.atlassian.net/browse/PROJ-123)`

**Best practices:**
- Include the report date prominently
- Link directly to relevant Jira issues
- Use consistent naming conventions for recurring reports
- Consider creating under a "Status Reports" parent page for organization

### Finding the Right Space

If the user doesn't specify a Confluence space:

1. Ask the user directly: "Which space key should I use? (e.g., TEAM, ENG, DOCS)"
2. Use `confluence_search` to find existing status report pages and identify the space pattern
3. Common space keys: TEAM, ENG, PROJ, DOCS, KB

### Updating Existing Reports

If updating an existing page instead of creating new:

1. Get the current page content:
```
confluence_get_page(
  page_id="123456",
  convert_to_markdown=true
)
```

2. Update the page with new content:
```
confluence_update_page(
  page_id="123456",
  title="Project Phoenix - Weekly Status - Dec 8, 2025",
  body="[updated report content]"
)
```

**Note:** The community version automatically handles version management.

---

## Complete Example Workflow

**User request:** "Generate a status report for Project Phoenix and publish it to Confluence"

**Step 1 - Identify scope:**
- Project: Phoenix (need to find project key)
- Time period: Last week (default)
- Audience: Not specified, assume executive level
- Destination: Confluence, need to ask for space key

**Step 2 - Query Jira:**
```
# Find project key first
jira_get_all_projects()

# Query completed issues
jira_search(
  jql="project = PHX AND status = Done AND resolved >= -7d",
  limit=50
)

# Query blocked issues
jira_search(
  jql="project = PHX AND status = Blocked",
  limit=50
)

# Query in-progress high priority
jira_search(
  jql="project = PHX AND status IN ('In Progress', 'In Review') AND priority IN (Highest, High)",
  limit=50
)
```

**Step 3 - Analyze:**
- 15 issues completed (metrics)
- 3 critical blockers (key insight)
- Major accomplishment: API integration completed (highlight)

**Step 4 - Format:**
Use Executive Summary Format. Create concise report with metrics, highlights, and blockers.

**Step 5 - Publish:**
```
# Ask user for space key
# "Which Confluence space key should I use for this report?"

# Create page
confluence_create_page(
  space_key="TEAM",
  title="Project Phoenix - Weekly Status - Dec 3, 2025",
  body="[formatted markdown report]"
)
```

---

## Tips for Quality Reports

**Be data-driven:**
- Include specific numbers and metrics
- Reference issue keys directly
- Show trends when possible (e.g., "completed 15 vs 12 last week")

**Highlight what matters:**
- Lead with the most important information
- Flag blockers prominently
- Celebrate significant wins

**Make it actionable:**
- For blockers, state what action is needed and from whom
- For risks, provide mitigation options
- For priorities, be specific about next steps

**Keep it consistent:**
- Use the same format for recurring reports
- Maintain predictable structure
- Include comparable metrics week-over-week

**Provide context:**
- Link to Jira for details
- Explain the impact of blockers
- Connect work to business objectives when possible

---

## Report Templates

### Executive Summary Template

```markdown
# [Project Name] - Status Report
**Period:** [Date Range]
**Status:** [On Track / At Risk / Blocked]

## Key Metrics
| Metric | Count |
|--------|-------|
| Completed | X |
| In Progress | X |
| Blocked | X |
| Total Open | X |

## Highlights
- [Major accomplishment 1]
- [Major accomplishment 2]
- [Major accomplishment 3]

## Blockers
| Issue | Blocker | Action Needed |
|-------|---------|---------------|
| [KEY-123] | [Description] | [Who needs to do what] |

## Upcoming Priorities
1. [Priority 1]
2. [Priority 2]
3. [Priority 3]
```

### Team Report Template

```markdown
# [Project Name] - Team Status Update
**Period:** [Date Range]

## Completed This Period
- [KEY-123] - [Summary] (Assignee)
- [KEY-124] - [Summary] (Assignee)

## In Progress
| Issue | Summary | Assignee | Priority |
|-------|---------|----------|----------|
| KEY-125 | [Summary] | [Name] | High |

## Blocked
- [KEY-126] - [Summary]
  - Blocker: [Description]
  - Action: [What needs to happen]

## Next Period
- [Planned work items]
```

### Daily Standup Template

```markdown
# Daily Update - [Date]

## Yesterday
- [KEY-123] - Completed [what]
- [KEY-124] - Made progress on [what]

## Today
- [KEY-125] - Will work on [what]
- [KEY-126] - Planning to [what]

## Blockers
- [Any blockers or none]
```
